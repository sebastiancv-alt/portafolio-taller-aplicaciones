package tienda;

import java.util.Locale;

/**
 * Clase que modela una venta de productos por docenas.
 * Calcula el importe de compra, aplica descuento según cantidad
 * y determina el obsequio de lapiceros.
 *
 * Actividad 01 - Programación Orientada a Objetos
 * Autor: [Tu Nombre]
 */
public class Venta {

    // Atributos privados
    private final String nombreProducto;
    private double precioPorDocena;
    private int docenasCompradas;

    private double montoCompra;
    private double tasaDescuento;
    private double montoDescuento;
    private double totalPagar;
    private int lapicerosRegalo;

    // Constructor
    public Venta(String nombreProducto, double precioPorDocena, int docenasCompradas) {
        this.nombreProducto = nombreProducto;
        this.precioPorDocena = precioPorDocena;
        this.docenasCompradas = docenasCompradas;
    }

    // Getters
    public String getNombreProducto() {
        return nombreProducto;
    }

    public double getPrecioPorDocena() {
        return precioPorDocena;
    }

    public int getDocenasCompradas() {
        return docenasCompradas;
    }

    public double getMontoCompra() {
        return montoCompra;
    }

    public double getTasaDescuento() {
        return tasaDescuento;
    }

    public double getMontoDescuento() {
        return montoDescuento;
    }

    public double getTotalPagar() {
        return totalPagar;
    }

    public int getLapicerosRegalo() {
        return lapicerosRegalo;
    }

    // Métodos de cálculo

    /**
     * Calcula el importe bruto de la compra.
     */
    public void calcularMontoCompra() {
        montoCompra = precioPorDocena * docenasCompradas;
    }

    /**
     * Determina el porcentaje de descuento:
     * - 20% si se compran 10 o más docenas
     * - 10% en caso contrario
     */
    public void calcularTasaDescuento() {
        if (docenasCompradas >= 10) {
            tasaDescuento = 0.20;
        } else {
            tasaDescuento = 0.10;
        }
    }

    /**
     * Calcula el valor monetario del descuento.
     */
    public void calcularMontoDescuento() {
        montoDescuento = montoCompra * tasaDescuento;
    }

    /**
     * Calcula el importe final a pagar.
     */
    public void calcularTotalPagar() {
        totalPagar = montoCompra - montoDescuento;
    }

    /**
     * Calcula la cantidad de lapiceros de obsequio:
     * 2 por cada docena si el total a pagar es >= 200, sino 0.
     */
    public void calcularLapicerosRegalo() {
        if (totalPagar >= 200) {
            lapicerosRegalo = 2 * docenasCompradas;
        } else {
            lapicerosRegalo = 0;
        }
    }

    /**
     * Ejecuta todos los cálculos en el orden correcto.
     */
    public void procesarVenta() {
        calcularMontoCompra();
        calcularTasaDescuento();
        calcularMontoDescuento();
        calcularTotalPagar();
        calcularLapicerosRegalo();
    }

    /**
     * Muestra el detalle de la venta al cliente.
     */
    public void mostrarDetalle() {
        System.out.println();
        System.out.println("--------------------------------------------------");
        System.out.println("           DETALLE DE LA VENTA");
        System.out.println("--------------------------------------------------");
        System.out.println("Producto              : " + nombreProducto);
        System.out.printf(Locale.US, "Precio por docena     : S/. %.2f%n", precioPorDocena);
        System.out.println("Docenas adquiridas    : " + docenasCompradas);
        System.out.println("--------------------------------------------------");
        System.out.printf(Locale.US, "Importe de la compra  : S/. %.2f%n", montoCompra);

        if (docenasCompradas >= 10) {
            System.out.println("Descuento aplicado    : 20% (compra mayor o igual a 10 docenas)");
        } else {
            System.out.println("Descuento aplicado    : 10% (compra menor a 10 docenas)");
        }
        System.out.printf(Locale.US, "Monto del descuento   : S/. %.2f%n", montoDescuento);
        System.out.println("--------------------------------------------------");
        System.out.printf(Locale.US, "TOTAL A PAGAR         : S/. %.2f%n", totalPagar);
        System.out.println("--------------------------------------------------");

        if (lapicerosRegalo > 0) {
            System.out.println("¡Felicidades! Obtiene obsequio de lapiceros.");
            System.out.println("Lapiceros de regalo   : " + lapicerosRegalo
                    + " (2 por cada docena)");
        } else {
            System.out.println("No aplica obsequio de lapiceros (total menor a S/. 200).");
            System.out.println("Lapiceros de regalo   : 0");
        }
        System.out.println("--------------------------------------------------");
        System.out.println("          ¡Gracias por su preferencia!");
        System.out.println("--------------------------------------------------");
    }
}
