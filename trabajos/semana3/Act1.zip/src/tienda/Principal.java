package tienda;

import java.util.Locale;
import java.util.Scanner;

/**
 * Clase principal del sistema de ventas de la tienda.
 * Permite atender a varios clientes en una misma ejecución.
 *
 * Actividad 01 - Programación Orientada a Objetos
 * Autor: [Tu Nombre]
 */
public class Principal {

    private static final Scanner entrada = new Scanner(System.in);

    public static void main(String[] args) {
        entrada.useLocale(Locale.US);

        mostrarEncabezado();

        int contadorClientes = 0;
        char continuar;

        do {
            contadorClientes++;
            System.out.println();
            System.out.println("============= CLIENTE N° " + contadorClientes + " =============");

            // Lectura y validación del precio
            double precio;
            do {
                System.out.print("Precio de la docena (S/.): ");
                precio = entrada.nextDouble();
                if (precio <= 0) {
                    System.out.println("  → El precio debe ser mayor que cero.");
                }
            } while (precio <= 0);

            // Lectura y validación de la cantidad
            int cantidad;
            do {
                System.out.print("Cantidad de docenas     : ");
                cantidad = entrada.nextInt();
                if (cantidad <= 0) {
                    System.out.println("  → La cantidad debe ser mayor que cero.");
                }
            } while (cantidad <= 0);

            // Crear objeto, procesar y mostrar
            Venta venta = new Venta("Cuaderno escolar", precio, cantidad);
            venta.procesarVenta();
            venta.mostrarDetalle();

            System.out.print("\n¿Atender a otro cliente? (S/N): ");
            continuar = entrada.next().toUpperCase().charAt(0);
            entrada.nextLine(); // limpiar buffer

        } while (continuar == 'S');

        System.out.println();
        System.out.println("Se atendieron " + contadorClientes + " cliente(s).");
        System.out.println("Fin del programa. ¡Hasta luego!");
    }

    private static void mostrarEncabezado() {
        System.out.println("==================================================");
        System.out.println("       SISTEMA DE VENTAS - TIENDA ESCOLAR");
        System.out.println("==================================================");
        System.out.println("Promoción vigente:");
        System.out.println("  • Descuento 20%  →  10 o más docenas");
        System.out.println("  • Descuento 10%  →  menos de 10 docenas");
        System.out.println("  • Obsequio       →  2 lapiceros por docena");
        System.out.println("                    si el total a pagar >= S/. 200");
        System.out.println("==================================================");
    }
}
