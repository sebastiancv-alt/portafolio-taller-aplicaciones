package transporte;

import java.util.Locale;
import java.util.Scanner;

/**
 * Clase principal del sistema de venta de pasajes.
 * Permite atender a varios clientes en una misma ejecución.
 *
 * Actividad 02 - Programación Orientada a Objetos
 * Autor: [Tu Nombre]
 */
public class Principal {

    private static final Scanner entrada = new Scanner(System.in);

    public static void main(String[] args) {
        entrada.useLocale(Locale.US);

        mostrarEncabezado();

        int contadorClientes = 0;
        char continuar;

        do {
            contadorClientes++;
            System.out.println();
            System.out.println("############# CLIENTE N° " + contadorClientes + " #############");

            // Lectura del turno
            String turno;
            do {
                System.out.print("Turno (Mañana / Noche): ");
                turno = entrada.next().trim();
                if (!turno.equalsIgnoreCase("Mañana") && !turno.equalsIgnoreCase("Noche")
                        && !turno.equalsIgnoreCase("Manana")) {
                    System.out.println("  → Ingrese 'Mañana' o 'Noche'.");
                    turno = "";
                } else {
                    // Normalizar
                    if (turno.equalsIgnoreCase("Manana") || turno.equalsIgnoreCase("Mañana")) {
                        turno = "Mañana";
                    } else {
                        turno = "Noche";
                    }
                }
            } while (turno.isEmpty());

            // Lectura y validación de la cantidad
            int cantidad;
            do {
                System.out.print("Cantidad de pasajes   : ");
                cantidad = entrada.nextInt();
                if (cantidad <= 0) {
                    System.out.println("  → La cantidad debe ser mayor que cero.");
                }
            } while (cantidad <= 0);

            // Crear objeto, procesar y mostrar
            Pasaje pasaje = new Pasaje(turno, cantidad);
            pasaje.procesarCompra();
            pasaje.mostrarBoleto();

            System.out.print("\n¿Atender a otro cliente? (S/N): ");
            continuar = entrada.next().toUpperCase().charAt(0);
            entrada.nextLine(); // limpiar buffer

        } while (continuar == 'S');

        System.out.println();
        System.out.println("Se atendieron " + contadorClientes + " cliente(s).");
        System.out.println("Fin del programa. ¡Hasta luego!");
    }

    private static void mostrarEncabezado() {
        System.out.println("==================================================");
        System.out.println("     SISTEMA DE VENTA DE PASAJES");
        System.out.println("          Ruta: Lima - Huancayo");
        System.out.println("==================================================");
        System.out.println("Precio del pasaje: S/. 37.50 (ambos turnos)");
        System.out.println();
        System.out.println("Promoción vigente:");
        System.out.println("  • Descuento 8%  →  15 o más pasajes");
        System.out.println("  • Descuento 5%  →  menos de 15 pasajes");
        System.out.println("  • Obsequio      →  2 caramelos por boleto");
        System.out.println("                   si el total a pagar > S/. 200");
        System.out.println("==================================================");
    }
}
