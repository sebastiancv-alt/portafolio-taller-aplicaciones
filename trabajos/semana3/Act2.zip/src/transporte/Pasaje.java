package transporte;

import java.util.Locale;

/**
 * Clase que modela la compra de pasajes de la ruta Lima - Huancayo.
 * Calcula el importe, aplica descuento según cantidad de pasajes
 * y determina el obsequio de caramelos.
 *
 * Actividad 02 - Programación Orientada a Objetos
 * Autor: [Tu Nombre]
 */
public class Pasaje {

    // Precio fijo del pasaje (igual en ambos turnos)
    private static final double PRECIO_UNITARIO = 37.50;

    // Atributos
    private String turno;           // "Mañana" o "Noche"
    private int cantidadBoletos;

    private double montoCompra;
    private double tasaDescuento;
    private double montoDescuento;
    private double totalPagar;
    private int caramelosRegalo;

    // Constructor
    public Pasaje(String turno, int cantidadBoletos) {
        this.turno = turno;
        this.cantidadBoletos = cantidadBoletos;
    }

    // Getters
    public String getTurno() {
        return turno;
    }

    public int getCantidadBoletos() {
        return cantidadBoletos;
    }

    public double getPrecioUnitario() {
        return PRECIO_UNITARIO;
    }

    public double getMontoCompra() {
        return montoCompra;
    }

    public double getTasaDescuento() {
        return tasaDescuento;
    }

    public double getMontoDescuento() {
        return montoDescuento;
    }

    public double getTotalPagar() {
        return totalPagar;
    }

    public int getCaramelosRegalo() {
        return caramelosRegalo;
    }

    // Métodos de cálculo

    /**
     * Calcula el importe bruto de la compra.
     */
    public void calcularMontoCompra() {
        montoCompra = PRECIO_UNITARIO * cantidadBoletos;
    }

    /**
     * Determina el porcentaje de descuento:
     * - 8% si se compran 15 o más pasajes
     * - 5% en caso contrario
     */
    public void calcularTasaDescuento() {
        if (cantidadBoletos >= 15) {
            tasaDescuento = 0.08;
        } else {
            tasaDescuento = 0.05;
        }
    }

    /**
     * Calcula el valor monetario del descuento.
     */
    public void calcularMontoDescuento() {
        montoDescuento = montoCompra * tasaDescuento;
    }

    /**
     * Calcula el importe final a pagar.
     */
    public void calcularTotalPagar() {
        totalPagar = montoCompra - montoDescuento;
    }

    /**
     * Calcula la cantidad de caramelos de obsequio:
     * 2 por cada boleto si el total a pagar es mayor a 200, sino 0.
     */
    public void calcularCaramelosRegalo() {
        if (totalPagar > 200) {
            caramelosRegalo = 2 * cantidadBoletos;
        } else {
            caramelosRegalo = 0;
        }
    }

    /**
     * Ejecuta todos los cálculos en el orden correcto.
     */
    public void procesarCompra() {
        calcularMontoCompra();
        calcularTasaDescuento();
        calcularMontoDescuento();
        calcularTotalPagar();
        calcularCaramelosRegalo();
    }

    /**
     * Muestra el boleto / detalle de la compra al cliente.
     */
    public void mostrarBoleto() {
        System.out.println();
        System.out.println("==================================================");
        System.out.println("              BOLETO DE VIAJE");
        System.out.println("           Ruta: Lima - Huancayo");
        System.out.println("==================================================");
        System.out.println("Turno                 : " + turno);
        System.out.printf(Locale.US, "Precio del pasaje     : S/. %.2f%n", PRECIO_UNITARIO);
        System.out.println("Cantidad de pasajes   : " + cantidadBoletos);
        System.out.println("--------------------------------------------------");
        System.out.printf(Locale.US, "Importe de la compra  : S/. %.2f%n", montoCompra);

        if (cantidadBoletos >= 15) {
            System.out.println("Descuento aplicado    : 8% (15 o más pasajes)");
        } else {
            System.out.println("Descuento aplicado    : 5% (menos de 15 pasajes)");
        }
        System.out.printf(Locale.US, "Monto del descuento   : S/. %.2f%n", montoDescuento);
        System.out.println("--------------------------------------------------");
        System.out.printf(Locale.US, "TOTAL A PAGAR         : S/. %.2f%n", totalPagar);
        System.out.println("--------------------------------------------------");

        if (caramelosRegalo > 0) {
            System.out.println("¡Obsequio aplicado!");
            System.out.println("Caramelos de regalo   : " + caramelosRegalo
                    + " (2 por cada boleto)");
        } else {
            System.out.println("No aplica obsequio de caramelos (total <= S/. 200).");
            System.out.println("Caramelos de regalo   : 0");
        }
        System.out.println("==================================================");
        System.out.println("         ¡Buen viaje y gracias por viajar con nosotros!");
        System.out.println("==================================================");
    }
}
