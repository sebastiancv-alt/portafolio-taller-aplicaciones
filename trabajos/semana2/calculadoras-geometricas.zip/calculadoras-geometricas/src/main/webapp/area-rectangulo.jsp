<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Área y Perímetro del Rectángulo</title>
    <link rel="stylesheet" href="css/area-rectangulo.css?v=4">
</head>
<body>
    <header class="topbar">
        <a href="menu.jsp" class="brand">
            <img src="images/logo.png" alt="UPLA" class="logo">
        </a>
        <h1 class="app-title">Área y Perímetro del Rectángulo</h1>
        <div class="topbar-right">
            <div class="window-dots">
                <span class="dot dot-red"></span>
                <span class="dot dot-yellow"></span>
                <span class="dot dot-green"></span>
            </div>
            <a href="menu.jsp" id="btnVolver" role="button" class="btn-regresar-esquina" title="Volver al menú">&larr; Menú</a>
        </div>
    </header>

    <main class="content">
        <section class="panel panel-form">
            <h2>Cálculo de Área y Perímetro</h2>
            <p class="subtitle">Introduce la base y la altura para obtener las propiedades del rectángulo.</p>

            <label for="ladoBase">Base (b)</label>
            <div class="input-row">
                <input type="number" id="ladoBase" step="0.01" placeholder="0.00">
                <select id="unidadBase" class="unit-select">
                    <option value="mm">mm</option>
                    <option value="cm" selected>cm</option>
                    <option value="m">m</option>
                    <option value="in">in</option>
                </select>
            </div>

            <label for="ladoAltura">Altura (h)</label>
            <div class="input-row">
                <input type="number" id="ladoAltura" step="0.01" placeholder="0.00">
                <select id="unidadAltura" class="unit-select">
                    <option value="mm">mm</option>
                    <option value="cm" selected>cm</option>
                    <option value="m">m</option>
                    <option value="in">in</option>
                </select>
            </div>

            <div class="btn-row">
                <button id="btnCalcular" type="button" class="btn-primary">Calcular</button>
                <button id="btnLimpiar" type="button" class="btn-secondary">Limpiar</button>
            </div>

            <div class="resultados">
                <span class="resultados-label">RESULTADOS</span>
                <div class="resultados-grid">
                    <div>
                        <span class="res-nombre">Área (A)</span>
                        <span id="resultadoArea" class="res-valor">0.00 cm&sup2;</span>
                    </div>
                    <div>
                        <span class="res-nombre">Perímetro (P)</span>
                        <span id="resultadoPerimetro" class="res-valor">0.00 cm</span>
                    </div>
                </div>
            </div>
        </section>

        <section class="panel panel-esquema">
            <h3>Esquema del Rectángulo</h3>
            <div class="dibujo">
                <svg id="svgFigura" viewBox="0 0 300 180" xmlns="http://www.w3.org/2000/svg">
                    <rect id="svgRect" x="40" y="30" width="220" height="100" fill="#E0E0FA" stroke="#4F46E5" stroke-width="2"/>
                    <text id="etiquetaH" x="270" y="80" font-size="13" fill="#4F46E5" text-anchor="start">h = 0.00 cm</text>
                    <text id="etiquetaB" x="150" y="150" font-size="13" fill="#4F46E5" text-anchor="middle">b = 0.00 cm</text>
                </svg>
            </div>
            <div class="formulas">
                <p class="formulas-title">Fórmulas aplicadas:</p>
                <p><strong>Área:</strong> A = b &times; h</p>
                <p><strong>Perímetro:</strong> P = 2 &times; (b + h)</p>
            </div>
        </section>
    </main>

    <footer class="footer">
        Desarrollado por: Sanchez Zuñiga Franchesco Marchelo
    </footer>

    <script src="js/area-rectangulo.js?v=4"></script>
</body>
</html>
