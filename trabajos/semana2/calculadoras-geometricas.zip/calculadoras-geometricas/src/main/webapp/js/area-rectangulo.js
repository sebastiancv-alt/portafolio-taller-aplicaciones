document.addEventListener('DOMContentLoaded', function () {
    var campoBase = document.getElementById('ladoBase');
    var campoAltura = document.getElementById('ladoAltura');
    var selectBase = document.getElementById('unidadBase');
    var selectAltura = document.getElementById('unidadAltura');
    var btnCalcular = document.getElementById('btnCalcular');
    var btnLimpiar = document.getElementById('btnLimpiar');
    var resultadoArea = document.getElementById('resultadoArea');
    var resultadoPerimetro = document.getElementById('resultadoPerimetro');
    var svgRect = document.getElementById('svgRect');
    var etiquetaB = document.getElementById('etiquetaB');
    var etiquetaH = document.getElementById('etiquetaH');

    // Mantiene las unidades de base y altura sincronizadas
    selectBase.addEventListener('change', function () { selectAltura.value = selectBase.value; });
    selectAltura.addEventListener('change', function () { selectBase.value = selectAltura.value; });

    btnCalcular.addEventListener('click', calcular);
    btnLimpiar.addEventListener('click', limpiar);

    function limpiar() {
        campoBase.value = '';
        campoAltura.value = '';
        selectBase.value = 'cm';
        selectAltura.value = 'cm';
        mostrar(0, 0, 0, 0, 'cm');
        campoBase.focus();
    }

    function calcular() {
        if (campoBase.value.trim() === '' || campoAltura.value.trim() === '') {
            alert('Ingresa la base y la altura.');
            return;
        }
        var b = parseFloat(campoBase.value);
        var h = parseFloat(campoAltura.value);
        if (isNaN(b) || isNaN(h) || b <= 0 || h <= 0) {
            alert('Ingresa valores numéricos válidos (mayores a 0).');
            return;
        }
        mostrar(b, h, b * h, 2 * (b + h), selectBase.value);
    }

    function mostrar(b, h, area, perimetro, unidad) {
        resultadoArea.innerHTML = area.toFixed(2) + ' ' + unidad + '<sup>2</sup>';
        resultadoPerimetro.textContent = perimetro.toFixed(2) + ' ' + unidad;
        actualizarEsquema(b, h, unidad);
    }

    function actualizarEsquema(b, h, unidad) {
        var escala = Math.min(220 / Math.max(b, 1), 100 / Math.max(h, 1), 30);
        var ancho = Math.max(b * escala, 30);
        var alto = Math.max(h * escala, 20);
        svgRect.setAttribute('width', ancho);
        svgRect.setAttribute('height', alto);
        svgRect.setAttribute('x', (280 - ancho) / 2);
        svgRect.setAttribute('y', (140 - alto) / 2 + 10);
        etiquetaB.textContent = 'b = ' + b.toFixed(2) + ' ' + unidad;
        etiquetaH.textContent = 'h = ' + h.toFixed(2) + ' ' + unidad;
    }

});
