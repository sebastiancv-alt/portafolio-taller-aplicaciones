<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Calculadoras Geométricas UPLA</title>
    <link rel="stylesheet" href="css/menu.css?v=4">
</head>
<body>
    <header class="topbar">
        <div class="brand">
            <img src="images/logo.png" alt="UPLA" class="logo">
        </div>
        <h1 class="app-title">Calculadoras Geométricas UPLA</h1>
        <div class="window-dots">
            <span class="dot dot-red"></span>
            <span class="dot dot-yellow"></span>
            <span class="dot dot-green"></span>
        </div>
    </header>

    <main class="menu-content">
        <p class="menu-subtitle">Elige la herramienta de cálculo geométrico que necesitas.</p>

        <div class="tarjetas">
            <a href="area-rectangulo.jsp" class="tarjeta tarjeta-morada">
                <h2>Área y Perímetro del Rectángulo</h2>
                <p>Obtén el área y el perímetro ingresando base y altura.</p>
                <span class="tarjeta-link">Abrir &rarr;</span>
            </a>

            <a href="teorema-pitagoras.jsp" class="tarjeta tarjeta-verde">
                <h2>Teorema de Pitágoras</h2>
                <p>Calcula la hipotenusa de un triángulo rectángulo con sus catetos.</p>
                <span class="tarjeta-link">Abrir &rarr;</span>
            </a>
        </div>
    </main>

    <footer class="footer">
        Desarrollado por: Sanchez Zuñiga Franchesco Marchelo
    </footer>
</body>
</html>
